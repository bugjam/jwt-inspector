chrome.devtools.panels.create(
  "JWT", "", "jwt-panel.html", function(panel) {}
  );
